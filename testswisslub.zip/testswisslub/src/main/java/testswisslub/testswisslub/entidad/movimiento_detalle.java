package testswisslub.testswisslub.entidad;

import jakarta.persistence.*;
import lombok.*;

import javax.naming.Name;
import java.util.Date;
import java.util.List;


@Entity
@ToString
@EqualsAndHashCode
@NoArgsConstructor

@Table(name="movimiento_detalle")
public class movimiento_detalle {



    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    @Getter
    @Setter
    private int id;


    @Column(name="item_codigo",length = 20)
    @Getter
    @Setter
    private String item_codigo;

    @Column(name="cantidad_enviada")
    @Getter
    @Setter
    private int cantidad_enviada;

    @ManyToOne
    private  MovimientoEntidad movimiento_id;











}


