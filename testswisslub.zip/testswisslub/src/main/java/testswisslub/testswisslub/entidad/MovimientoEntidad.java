package testswisslub.testswisslub.entidad;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;


@Entity
    @ToString
    @EqualsAndHashCode
    @NoArgsConstructor

    @Table(name="movimiento")
    public class MovimientoEntidad {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name="id")
        @Getter
        @Setter
        private int id;

        @Column(name="Id_empresa")
        @Getter
        @Setter
        private int Id_empresa;

        @Column(name="descripcion")
        @Getter
        @Setter
        private String descripcion;

        @Column(name="bodega_origen_codigo", length = 20)
        @Getter
        @Setter
        private String bodega_origen_codigo;

        @Column(name="bodega_destino_codigo", length = 20)
        @Getter
        @Setter
        private String bodega_destino_codigo;

        @Column(name="fecha_creacion")
        @Getter @Setter
        @Temporal(TemporalType.DATE)
        private Date fecha_creacion;

        @Column(name="fecha_entrega")
        @Getter @Setter
        @Temporal(TemporalType.DATE)
        private Date fecha_entrega;

        @Column(name= "estado")
        @Getter
        @Setter
        private String estado;


        @OneToMany(mappedBy ="movimiento_id")
    List<movimiento_detalle> Movimiento_detalle;

}









