package testswisslub.testswisslub.controlador;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import testswisslub.testswisslub.entidad.MovimientoEntidad;
import testswisslub.testswisslub.entidad.movimiento_detalle;
import testswisslub.testswisslub.servicio.MovimientoServicioImpl;

import java.util.List;

@Controller
public class MovimientoControlador {

    @Autowired
    private MovimientoServicioImpl movimientoServicio;


    //Lista Movimientos

    @GetMapping("/")
    public String verPaginadeinicio(Model modelo){
        List<MovimientoEntidad> listaMovimientoEntidads = movimientoServicio.listarTodoslosMovimientos();
        modelo.addAttribute("listaMovimientoEntidads", listaMovimientoEntidads);
        return "movimientos";
    }
    @RequestMapping("/nuevo")
    public String nuevoMovimentos(Model modelo) {
        modelo.addAttribute("nuevoMov", new movimiento_detalle());
        return "nuevo";
    }

    }
