package testswisslub.testswisslub.controlador;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import testswisslub.testswisslub.entidad.MovimientoEntidad;
import testswisslub.testswisslub.entidad.movimiento_detalle;
import testswisslub.testswisslub.servicio.MovimientoServicioImpl;
import testswisslub.testswisslub.servicio.detalleServicioImpl;

import java.util.List;

@Controller
public class detalleControlador {

    @Autowired
    private detalleServicioImpl detalleServicio;


    //Lista Movimientos

    @GetMapping("/detalles")
    public String verdetalles(Model modelo){
        List<movimiento_detalle> listaDetalles = detalleServicio.listarTodoslosdetalles();
        modelo.addAttribute("listaMovDetalles",listaDetalles);
        return "detalles";
    }
    

    }
