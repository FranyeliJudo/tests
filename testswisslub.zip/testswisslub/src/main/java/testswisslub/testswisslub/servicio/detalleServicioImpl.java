package testswisslub.testswisslub.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import testswisslub.testswisslub.entidad.MovimientoEntidad;
import testswisslub.testswisslub.entidad.movimiento_detalle;
import testswisslub.testswisslub.repositorio.MovimientoRepositorio;
import testswisslub.testswisslub.repositorio.detalleRepositorio;

import java.util.List;

@Service
public class detalleServicioImpl {
   @Autowired
   private detalleRepositorio DetalleRepositorio;

    public List<movimiento_detalle> listarTodoslosdetalles() {
        return listarTodoslosdetalles();
    }

}
