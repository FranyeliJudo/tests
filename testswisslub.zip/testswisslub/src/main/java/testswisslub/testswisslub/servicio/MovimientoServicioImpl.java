package testswisslub.testswisslub.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import testswisslub.testswisslub.entidad.MovimientoEntidad;
import testswisslub.testswisslub.entidad.movimiento_detalle;
import testswisslub.testswisslub.repositorio.MovimientoRepositorio;

import java.util.List;

@Service
public class MovimientoServicioImpl {
   @Autowired
   private MovimientoRepositorio movimientoRepositorio;

    public List<MovimientoEntidad> listarTodoslosMovimientos() {
        return movimientoRepositorio.findAll();
    }





}
