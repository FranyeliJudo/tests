package testswisslub.testswisslub.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import testswisslub.testswisslub.entidad.MovimientoEntidad;


@Repository
public interface MovimientoRepositorio extends JpaRepository<MovimientoEntidad, Long> {

}

