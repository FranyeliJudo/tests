package testswisslub.testswisslub.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import testswisslub.testswisslub.entidad.MovimientoEntidad;
import testswisslub.testswisslub.entidad.movimiento_detalle;


@Repository
public interface detalleRepositorio extends JpaRepository<movimiento_detalle, Long> {

}

