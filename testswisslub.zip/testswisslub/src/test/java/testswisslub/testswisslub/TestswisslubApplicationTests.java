package testswisslub.testswisslub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestswisslubApplicationTests {

	@Test
	void contextLoads() {
	}

}
